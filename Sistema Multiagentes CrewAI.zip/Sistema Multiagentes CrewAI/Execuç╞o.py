#Execução do projeto:

from Pydantic import Artigo
from Multiagente import *
from flask import (
    Flask,
    request,
    jsonify
)

#Definição do assunto do artigo:
assArt = "Inteligência Artificial da Wikipédia"

#Criação do Flask para a execução do API:
app = Flask(__name__)

@app.route('/gerar_artigo', methods=['GET' ,'POST'])
def gerar_artigo():
    data = request.get_json()
    assunto = data.get('assunto')
    if not assunto:
        return jsonify({"ERRO": "O uso do parâmetro 'assunto' é obrigatório."}), 400

    #Atualização do assunto na tarefa de pesquisa:
    pesqTask.description = pesqTask.description.format(assunto=assunto)

    # Execução da Crew para a geração do determinado artigo:
    print(f"Iniciando a criação do artigo sobre: {assArt}\n")
    artGer = artCrew.kickoff()
    print(f"Artigo gerado: {artGer}\n")

    #Formatação da saída usando Pydantic:
    form = Artigo(titulo=f"Artigo sobre {assunto}", conteudo=artGer, 
                           fonte="Wikipedia")

    return jsonify(form.model_dump_json()), 200

if __name__ == '__main__':
    app.run(debug=True)