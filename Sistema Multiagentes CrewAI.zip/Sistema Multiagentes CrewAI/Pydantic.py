#Criação do Output pydantic:

from pydantic import (
    BaseModel,
    Field
)

class Artigo(BaseModel):
    titulo: str = Field(description="Título do artigo")
    conteudo: str = Field(description="Conteúdo do artigo")
    fonte: str = Field(description="Fonte do artigo")