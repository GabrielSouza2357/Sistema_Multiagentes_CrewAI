#Criação do sistema multiagente:

from ChavesAPI import *
from Tools import *
from crewai import (
    Agent,
    Task,
    Crew
)

#Agentes:

#Agente Pesquisador:
pesq = Agent(
    role='Pesquisador de Conteúdo Web',
    goal='''Coletar informações relevantes e detalhadas sobre um determinado 
    assunto usando a Wikipedia.''',
    backstory='''Um especialista em pesquisa online com acesso a vastos recursos 
    de informação.''',
    tools=[serp, scrap],
    verbose=True,
    llm=llm
)

#Agente Escritor:
esc = Agent(
    role='Escritor de Artigos Web',
    goal='''Escrever artigos informativos e envolventes com um mínimo de 
    300 palavras, com base nas informações fornecidas pelo pesquisador.''',
    backstory='Um redator habilidoso com experiência em criar conteúdo otimizado para web.',
    tools=[serp, scrap],
    verbose=True,
    llm=llm
)

#Agente Revisor:
rev = Agent(
    role='Revisor de Conteúdo',
    goal='''Garantir a qualidade, precisão e clareza dos artigos, corrigindo 
    erros gramaticais, ortográficos e de coerência.''',
    backstory='Um editor meticuloso com um olhar atento aos detalhes.',
    tools=[serp, scrap],
    verbose=True,
    llm=llm
)

#Tarefas:

#Tarefa de Pesquisa:
pesqTask = Task(
    description='''Pesquise detalhadamente na Wikipedia por informações relevantes 
    sobre o assunto do artigo. Concentre-se em fatos, história, principais 
    conceitos e qualquer outra informação relevante para um artigo informativo.''',
    expected_output='Tarefa de pesquisa sobre o assunto. ',
    agent=pesq
)

#Tarefa de Escrita:
escTask = Task(
    description='''Escreva um artigo informativo e envolvente com um mínimo 
    de 300 palavras sobre o seguinte tópico: {assunto}, utilizando 
    as informações fornecidas pela pesquisa. Mantenha um tom claro e conciso.''',
    expected_output='Tarefa de escrita do artigo sobre o assunto. ',
    agent=esc
)

#Tarefa de Revisão:
revTask = Task(
    description='''Revise cuidadosamente o artigo gerado, verificando a 
    gramática, ortografia, coerência, precisão das informações e se o 
    artigo atinge o mínimo de 300 palavras. Forneça um feedback detalhado 
    sobre quaisquer melhorias necessárias.''',
    expected_output='Tarefa de revisão sobre o assunto. ',
    agent=rev
)

#Crew:
artCrew = Crew(
    agents=[pesq, esc, rev],
    tasks=[pesqTask, escTask, revTask],
    verbose=True,
    planning=True,
    llm=llm
)