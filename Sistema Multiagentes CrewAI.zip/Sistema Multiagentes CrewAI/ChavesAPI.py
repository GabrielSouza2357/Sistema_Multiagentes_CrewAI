#Configuração das chaves API do Gemini: 

import os
import google.generativeai as genai
from langchain.utilities import WikipediaAPIWrapper
from google.colab import userdata

os.environ["MINHA_CHAVE_SERVER_DEV"] = userdata.get("MINHA_CHAVE_SERVER_DEV")
os.environ["GOOGLE_API_KEY"] = userdata.get("MINHA_CHAVE_GOOGLE_API")
genai.configure(api_key = os.environ["GOOGLE_API_KEY"])
modelo = "gemini-pro"
os.environ["GOOGLE_MODEL_NAME"] = modelo

llm = genai.GenerativeModel(model_name=modelo)
wiki = WikipediaAPIWrapper()