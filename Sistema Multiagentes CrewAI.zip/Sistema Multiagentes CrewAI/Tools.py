#Criação das Tools:

from ChavesAPI import *
from crewai_tools import (
    SerperDevTool,
    ScrapeWebsiteTool
)

serp = SerperDevTool()
scrap = ScrapeWebsiteTool()